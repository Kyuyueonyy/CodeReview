/**
 * 이름이 있는 내보내기
 * - 여러값을 내보낼 수 있다
 * - 반드시 기존 이름을 사용하거나, as를 통해 별칭을 부여
 */

const name = '홍길동';
const age = 30;

function greet() {
  return `안녕하세요 ${name} 입니다.`;
}
